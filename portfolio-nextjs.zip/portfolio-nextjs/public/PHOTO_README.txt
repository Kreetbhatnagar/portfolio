Place your profile photo here as: photo.jpeg

- Recommended: square image, at least 560x560px, JPEG format.
- The hero section references it as /photo.jpeg (see lib/data.js -> profile.photo).
- If the file is missing, the site automatically falls back to a placeholder icon
  (no crash, no broken-image icon).

Delete this PHOTO_README.txt file once photo.jpeg is in place (optional).
