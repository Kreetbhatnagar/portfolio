# Agent Instructions

This file orients any AI coding agent (Claude, Claude Code, Cursor, etc.)
working in this repository. Read this first, then read everything in
`memory-bank/` before making changes.

## What this repo is
A Next.js 14 (App Router) personal portfolio site for Kreet Bhatnagar,
deployed to Vercel with GitHub Actions CI. Single page, no backend, no
database.

## Read before you edit
1. `memory-bank/index.md` — map of the memory bank.
2. `memory-bank/PRD.md` — scope and intent. Don't add features listed under
   "Out of scope" without the user explicitly asking.
3. `memory-bank/design.md` — the design system. Don't introduce new colors,
   fonts, or a second styling system (e.g. Tailwind) without updating this
   file first and confirming with the user.
4. `memory-bank/tech-stack.md` — architecture and directory layout.
5. `memory-bank/resume.md` — canonical content. Cross-check `lib/data.js`
   against this before/after content changes.

## Hard rules
- **All page copy lives in `lib/data.js`.** Never hardcode names, dates,
  bullet points, or contact details directly in a component. If content
  changes, update both `memory-bank/resume.md` (the record) and
  `lib/data.js` (what renders).
- **Don't rename or remove section `id`s** (`#about`, `#experience`,
  `#skills`, `#certifications`, `#projects`, `#contact`) without also
  updating `navLinks` in `lib/data.js` and the footer links — they're
  used for in-page anchor navigation.
- **Client vs. server components**: only add `"use client"` to a component
  when it actually needs browser APIs, state, or effects (matches
  `useEffect`/`useState`/event handlers). Keep purely presentational
  section components as server components.
- **Styling**: use the existing CSS custom properties in
  `app/globals.css` (`var(--primary)`, `var(--text-light)`, etc.) for any
  new UI. Don't hardcode new hex colors.
- **Don't commit secrets.** Vercel/GitHub tokens belong in repo/environment
  secrets, never in code or `.env` files that get committed.
- **Before finishing a task**: run `npm run lint` and `npm run build`
  mentally (or actually, if you have shell access) — CI will fail the PR
  otherwise.

## Common tasks

**Update resume content (new job, new certification, etc.)**
1. Edit `memory-bank/resume.md`.
2. Mirror the change into the matching array/object in `lib/data.js`.
3. No component changes needed unless the shape of the data changes.

**Add a new section**
1. Add a data array to `lib/data.js`.
2. Create `components/<SectionName>.js` following the pattern of an
   existing section (e.g. `Certifications.js`) — a `<section>` with
   `section-container`, `section-header` (wrapped in `<Reveal>`), and a
   grid/list of items.
3. Add matching CSS to `app/globals.css` if the layout doesn't fit
   existing classes — reuse `.card`-style patterns already present.
4. Import and render it in `components/Portfolio.js` in the right order.
5. Add a nav entry to `navLinks` in `lib/data.js` if it should be
   reachable from the nav/footer.

**Change the deploy target or add environment variables**
Update `memory-bank/tech-stack.md` to reflect the change, and note it here
if it changes agent workflow (e.g. a new required secret).

## Verifying changes locally
```bash
npm install
npm run lint
npm run dev     # visually check http://localhost:3000
npm run build   # must succeed — this is what CI/Vercel run
```
