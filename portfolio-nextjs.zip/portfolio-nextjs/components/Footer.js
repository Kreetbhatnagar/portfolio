import { navLinks, profile } from "@/lib/data";

export default function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer>
      <div className="footer-content">
        <div className="footer-links">
          {navLinks.map((link) => (
            <a href={link.href} key={link.href}>
              {link.label}
            </a>
          ))}
        </div>
        <div className="footer-social">
          <a href={profile.linkedinHref} target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
            <i className="fab fa-linkedin-in" aria-hidden="true" />
          </a>
          <a href={profile.emailHref} aria-label="Email">
            <i className="fas fa-envelope" aria-hidden="true" />
          </a>
        </div>
        <p className="footer-copyright">
          &copy; {year} {profile.name}. All rights reserved.
        </p>
      </div>
    </footer>
  );
}
