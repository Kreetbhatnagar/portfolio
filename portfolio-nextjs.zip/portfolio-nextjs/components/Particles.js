"use client";

import { useEffect, useState } from "react";

const PARTICLE_COUNT = 30;

export default function Particles() {
  const [particles, setParticles] = useState([]);

  useEffect(() => {
    const generated = Array.from({ length: PARTICLE_COUNT }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 15,
      duration: Math.random() * 10 + 10,
      size: Math.random() * 4 + 2,
    }));
    setParticles(generated);
  }, []);

  return (
    <div className="particles" aria-hidden="true">
      {particles.map((p) => (
        <span
          key={p.id}
          className="particle"
          style={{
            left: `${p.left}%`,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            width: `${p.size}px`,
            height: `${p.size}px`,
          }}
        />
      ))}
    </div>
  );
}
