import { certifications } from "@/lib/data";
import Reveal from "@/components/Reveal";

export default function Certifications() {
  return (
    <section className="certifications" id="certifications">
      <div className="section-container">
        <Reveal className="section-header">
          <div className="section-label">
            <i className="fas fa-certificate" aria-hidden="true" />
            Certifications
          </div>
          <h2 className="section-title">Professional Credentials</h2>
          <p className="section-subtitle">Continuously expanding knowledge</p>
        </Reveal>
        <div className="certs-grid">
          {certifications.map((cert) => (
            <Reveal key={cert.title}>
              <div className="cert-card">
                <div className="cert-icon">
                  <i className={`fas ${cert.icon}`} aria-hidden="true" />
                </div>
                <div className="cert-info">
                  <h4>{cert.title}</h4>
                  <p>{cert.issuer}</p>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
