import { profile, highlights } from "@/lib/data";
import Reveal from "@/components/Reveal";
import TiltCard from "@/components/TiltCard";

export default function About() {
  return (
    <section className="about" id="about">
      <div className="section-container">
        <Reveal className="section-header">
          <div className="section-label">
            <i className="fas fa-user" aria-hidden="true" />
            About Me
          </div>
          <h2 className="section-title">Dedicated to Sustainable Impact</h2>
          <p className="section-subtitle">
            Passionate about driving ESG excellence and sustainability initiatives
          </p>
        </Reveal>
        <div className="about-grid">
          <Reveal className="about-text">
            {profile.aboutParagraphs.map((p) => (
              <p key={p.slice(0, 20)}>{p}</p>
            ))}
          </Reveal>
          <Reveal className="about-highlights">
            {highlights.map((h) => (
              <TiltCard className="highlight-card" key={h.title}>
                <div className="highlight-icon">
                  <i className={`fas ${h.icon}`} aria-hidden="true" />
                </div>
                <h4>{h.title}</h4>
                <p>{h.text}</p>
              </TiltCard>
            ))}
          </Reveal>
        </div>
      </div>
    </section>
  );
}
