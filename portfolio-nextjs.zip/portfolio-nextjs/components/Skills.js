import { skills } from "@/lib/data";
import Reveal from "@/components/Reveal";
import TiltCard from "@/components/TiltCard";

export default function Skills() {
  return (
    <section className="skills" id="skills">
      <div className="section-container">
        <Reveal className="section-header">
          <div className="section-label">
            <i className="fas fa-cogs" aria-hidden="true" />
            Skills
          </div>
          <h2 className="section-title">Expertise & Proficiencies</h2>
          <p className="section-subtitle">Technical and professional skills</p>
        </Reveal>
        <div className="skills-grid">
          {skills.map((cat) => (
            <Reveal key={cat.title}>
              <TiltCard className="skill-category">
                <div className="skill-category-icon">
                  <i className={`fas ${cat.icon}`} aria-hidden="true" />
                </div>
                <h3>{cat.title}</h3>
                <div className="skill-tags">
                  {cat.tags.map((tag) => (
                    <span className="skill-tag" key={tag}>
                      {tag}
                    </span>
                  ))}
                </div>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
