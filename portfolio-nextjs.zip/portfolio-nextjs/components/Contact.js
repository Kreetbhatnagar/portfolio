import { profile } from "@/lib/data";
import Reveal from "@/components/Reveal";

export default function Contact() {
  return (
    <section className="contact" id="contact">
      <div className="section-container">
        <Reveal className="section-header">
          <div className="section-label">
            <i className="fas fa-envelope" aria-hidden="true" />
            Contact
          </div>
          <h2 className="section-title">Get In Touch</h2>
          <p className="section-subtitle">
            Let&apos;s connect and discuss sustainability opportunities
          </p>
        </Reveal>
        <div className="contact-grid">
          <Reveal className="contact-card">
            <i className="fas fa-phone" aria-hidden="true" />
            <h4>Phone</h4>
            <p>
              <a href={profile.phoneHref}>{profile.phone}</a>
            </p>
          </Reveal>
          <Reveal className="contact-card">
            <i className="fas fa-envelope" aria-hidden="true" />
            <h4>Email</h4>
            <p>
              <a href={profile.emailHref}>{profile.email}</a>
            </p>
          </Reveal>
          <Reveal className="contact-card">
            <i className="fab fa-linkedin" aria-hidden="true" />
            <h4>LinkedIn</h4>
            <p>
              <a href={profile.linkedinHref} target="_blank" rel="noopener noreferrer">
                {profile.linkedin}
              </a>
            </p>
          </Reveal>
        </div>
      </div>
    </section>
  );
}
