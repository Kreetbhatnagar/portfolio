import { experience, education } from "@/lib/data";
import Reveal from "@/components/Reveal";

export default function Experience() {
  return (
    <section className="experience" id="experience">
      <div className="section-container">
        <Reveal className="section-header">
          <div className="section-label">
            <i className="fas fa-briefcase" aria-hidden="true" />
            Experience
          </div>
          <h2 className="section-title">Professional Journey</h2>
          <p className="section-subtitle">Building expertise in ESG and sustainability</p>
        </Reveal>
        <div className="timeline">
          {experience.map((job, i) => (
            <Reveal
              as="div"
              key={job.company}
              className={`timeline-item ${i % 2 === 1 ? "timeline-even" : ""}`}
            >
              <div className="timeline-dot" />
              <div className="timeline-content">
                <div className="timeline-date">
                  <i className="fas fa-calendar-alt" aria-hidden="true" />
                  {job.date}
                </div>
                <h3>{job.role}</h3>
                <h4>{job.company}</h4>
                <ul>
                  {job.bullets.map((b) => (
                    <li key={b.slice(0, 24)}>{b}</li>
                  ))}
                </ul>
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal className="section-header" style={{ marginTop: "5rem" }}>
          <div className="section-label">
            <i className="fas fa-graduation-cap" aria-hidden="true" />
            Education
          </div>
          <h2 className="section-title">Academic Background</h2>
        </Reveal>
        <Reveal className="education-grid">
          {education.map((edu) => (
            <div className="education-card" key={edu.degree}>
              <h3>{edu.degree}</h3>
              <p>{edu.school}</p>
              <p>
                <span className="edu-date">{edu.date}</span> · {edu.detail}
              </p>
            </div>
          ))}
        </Reveal>
      </div>
    </section>
  );
}
