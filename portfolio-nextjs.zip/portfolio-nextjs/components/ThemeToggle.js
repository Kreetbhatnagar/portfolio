"use client";

import { useEffect, useState } from "react";

export default function ThemeToggle() {
  const [theme, setTheme] = useState(null);

  useEffect(() => {
    const current = document.documentElement.getAttribute("data-theme") || "light";
    setTheme(current);
  }, []);

  const toggleTheme = () => {
    const next = theme === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    try {
      localStorage.setItem("theme", next);
    } catch (e) {
      // localStorage unavailable (e.g. private browsing) — theme just won't persist.
    }
    setTheme(next);
  };

  return (
    <button
      className="theme-toggle"
      id="themeToggle"
      aria-label="Toggle color theme"
      onClick={toggleTheme}
      type="button"
    >
      <i className={`fas ${theme === "dark" ? "fa-sun" : "fa-moon"}`} aria-hidden="true" />
    </button>
  );
}
