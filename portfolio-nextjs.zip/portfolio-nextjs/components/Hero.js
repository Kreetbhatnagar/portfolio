import { profile, stats } from "@/lib/data";
import Counter from "@/components/Counter";

export default function Hero() {
  return (
    <section className="hero" id="home">
      <div className="hero-content">
        <div className="hero-text">
          <div className="hero-badge">
            <i className="fas fa-leaf" aria-hidden="true" />
            {profile.title}
          </div>
          <h1>
            {profile.firstName} <span>{profile.lastName}</span>
          </h1>
          <p className="hero-subtitle">{profile.summary}</p>
          <div className="hero-cta">
            <a href="#contact" className="btn btn-primary">
              <i className="fas fa-envelope" aria-hidden="true" />
              Get In Touch
            </a>
            <a href="#experience" className="btn btn-outline">
              <i className="fas fa-briefcase" aria-hidden="true" />
              View Experience
            </a>
          </div>
          <div className="hero-stats">
            {stats.map((stat) => (
              <div className="stat" key={stat.label}>
                <Counter value={stat.value} suffix={stat.suffix} />
                <div className="stat-label">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="hero-photo">
          <div className="photo-container">
            <div className="photo-ring" />
            <div className="photo-ring ring-2" />
            <div className="photo-glow" />
            {/* Drop your photo at /public/photo.jpeg — falls back to an icon if missing */}
            <img
              src={profile.photo}
              alt={profile.name}
              className="photo-img"
              onError={(e) => {
                e.currentTarget.style.display = "none";
                const placeholder = e.currentTarget.parentElement.querySelector(
                  ".photo-placeholder"
                );
                if (placeholder) placeholder.style.display = "flex";
              }}
            />
            <div className="photo-placeholder" style={{ display: "none" }}>
              <i className="fas fa-user" aria-hidden="true" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
