"use client";

import { useEffect, useRef, useState } from "react";

export default function Counter({ value, suffix = "" }) {
  const ref = useRef(null);
  const [display, setDisplay] = useState("0");
  const isDecimal = value % 1 !== 0;

  useEffect(() => {
    const node = ref.current;
    if (!node) return undefined;

    let rafId;
    const runCount = () => {
      const duration = 2000;
      const step = value / (duration / 16);
      let current = 0;

      const tick = () => {
        current += step;
        if (current < value) {
          setDisplay(current.toFixed(isDecimal ? 1 : 0));
          rafId = requestAnimationFrame(tick);
        } else {
          setDisplay(`${isDecimal ? value.toFixed(1) : value}${suffix}`);
        }
      };
      tick();
    };

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          runCount();
          observer.unobserve(node);
        }
      },
      { threshold: 0.5 }
    );

    observer.observe(node);
    return () => {
      observer.disconnect();
      if (rafId) cancelAnimationFrame(rafId);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return (
    <div className="stat-number" ref={ref}>
      {display}
    </div>
  );
}
