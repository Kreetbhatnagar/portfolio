import { accomplishments } from "@/lib/data";
import Reveal from "@/components/Reveal";

export default function Accomplishments() {
  return (
    <section className="accomplishments" id="accomplishments">
      <div className="section-container">
        <Reveal className="section-header">
          <div className="section-label">
            <i className="fas fa-trophy" aria-hidden="true" />
            Accomplishments
          </div>
          <h2 className="section-title">Recognition & Achievements</h2>
          <p className="section-subtitle">Milestones in my professional journey</p>
        </Reveal>
        <div className="accomplishments-list">
          {accomplishments.map((item) => (
            <Reveal key={item.text.slice(0, 24)} className="accomplishment-item">
              <div className="accomplishment-icon">
                <i className={`fas ${item.icon}`} aria-hidden="true" />
              </div>
              <div className="accomplishment-text">{item.text}</div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
