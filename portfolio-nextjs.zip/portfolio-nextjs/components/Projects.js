import { projects } from "@/lib/data";
import Reveal from "@/components/Reveal";
import TiltCard from "@/components/TiltCard";

export default function Projects() {
  return (
    <section className="projects" id="projects">
      <div className="section-container">
        <Reveal className="section-header">
          <div className="section-label">
            <i className="fas fa-project-diagram" aria-hidden="true" />
            Key Projects
          </div>
          <h2 className="section-title">Impactful Work</h2>
          <p className="section-subtitle">Contributing to sustainability initiatives</p>
        </Reveal>
        <div className="projects-grid">
          {projects.map((project) => (
            <Reveal key={project.title}>
              <TiltCard className="project-card">
                <div className="project-icon">
                  <i className={`fas ${project.icon}`} aria-hidden="true" />
                </div>
                <h3>{project.title}</h3>
                <p>{project.text}</p>
              </TiltCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
