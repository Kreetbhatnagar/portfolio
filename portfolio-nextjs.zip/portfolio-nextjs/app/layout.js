import "./globals.css";
import { profile } from "@/lib/data";

export const metadata = {
  metadataBase: new URL("https://example.com"),
  title: `${profile.name} | ${profile.title}`,
  description: profile.summary,
  keywords: [
    "ESG",
    "Sustainability",
    "GRI",
    "SASB",
    "TCFD",
    "CDP",
    "BRSR",
    "CSRD",
    "IFRS S1/S2",
    "Kreet Bhatnagar",
  ],
  authors: [{ name: profile.name }],
  openGraph: {
    title: `${profile.name} | ${profile.title}`,
    description: profile.summary,
    type: "website",
  },
  robots: {
    index: true,
    follow: true,
  },
};

// Runs before paint to avoid a light/dark theme flash on load.
const themeInitScript = `
(function() {
  try {
    var stored = localStorage.getItem('theme');
    var theme = stored === 'dark' || stored === 'light'
      ? stored
      : (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
  } catch (e) {}
})();
`;

export default function RootLayout({ children }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap"
          rel="stylesheet"
        />
        <link
          rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        />
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body>
        <a href="#main-content" className="skip-link">
          Skip to content
        </a>
        {children}
      </body>
    </html>
  );
}
