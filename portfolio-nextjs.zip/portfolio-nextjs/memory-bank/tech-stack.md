# Tech Stack & Architecture

## Framework
- **Next.js 14** (App Router, `app/` directory), plain JavaScript (no
  TypeScript).
- **React 18**.
- Rendering: standard Next.js server + client components. Content
  sections (`Hero`, `About`, etc.) are server components; only the pieces
  that need interactivity (`Navbar`, `ThemeToggle`, `Particles`, `Reveal`,
  `Counter`, `TiltCard`) are marked `"use client"`.

## Styling
- Plain CSS, no framework (no Tailwind/CSS-in-JS/UI kit). One global
  stylesheet: `app/globals.css`, using CSS custom properties for theming
  (`:root` = light theme, `[data-theme="dark"]` = dark theme overrides).
- Rationale: the original design (`index.html`) was already fully styled
  in plain CSS; porting it 1:1 preserves visual fidelity and avoids a
  rewrite. If the project later adopts Tailwind or a component library,
  update this file and `design.md`.

## Fonts & icons
- Google Fonts (`Inter`, `Playfair Display`) via `<link>` tag in
  `app/layout.js`.
- Font Awesome 6 via CDN `<link>` in `app/layout.js`.
- Both are loaded via CDN rather than bundled npm packages to match the
  original design's approach and keep the dependency tree small. Can be
  swapped for `next/font` + a local icon set later for fully offline
  builds/better performance.

## Content architecture
- `lib/data.js` — single source of truth for all displayed content
  (profile info, stats, experience, education, skills, certifications,
  projects, accomplishments, nav links). Components import from here;
  no copy is hardcoded in JSX.
- `memory-bank/resume.md` — canonical human-readable resume; mirror
  changes into `lib/data.js`.

## Directory structure

```
app/
  layout.js       — root layout, metadata, fonts, theme-flash prevention script
  page.js         — renders <Portfolio />
  globals.css     — design system (colors, type, layout, animation)
components/
  Portfolio.js    — composes the whole page
  Navbar.js       — sticky nav, scroll shadow, mobile menu (client)
  ThemeToggle.js  — light/dark toggle, persisted to localStorage (client)
  Particles.js    — decorative floating particles (client)
  Reveal.js       — scroll-in-view fade/slide wrapper (client)
  Counter.js      — animated stat counter (client)
  TiltCard.js     — mouse-tilt hover effect wrapper (client)
  Hero.js, About.js, Experience.js, Skills.js, Certifications.js,
  Projects.js, Accomplishments.js, Contact.js, Footer.js — section components
lib/
  data.js         — all content
public/
  photo.jpeg      — profile photo (drop in yourself; falls back gracefully if missing)
  robots.txt
memory-bank/      — PRD, design system, tech stack, resume (this folder)
agent.md          — instructions for AI coding agents working in this repo
.github/workflows/
  ci.yml              — lint + build on every push/PR
  deploy-vercel.yml   — optional CLI-based Vercel deploy (disabled by default)
vercel.json       — Vercel project config (framework detection, build command)
```

## CI/CD

- **CI**: `.github/workflows/ci.yml` — on every push and pull request to
  `main`, installs dependencies, runs `npm run lint`, then `npm run build`.
  This is the merge gate.
- **CD**: Vercel's native GitHub integration is the primary deployment
  path — connect the repo in the Vercel dashboard once, and Vercel
  auto-builds/deploys:
  - every push to `main` → Production deployment.
  - every pull request → a unique Preview deployment with its own URL.
  - No secrets or extra workflow needed for this path.
- An **optional** `.github/workflows/deploy-vercel.yml` is included for
  teams that prefer deploys to run explicitly through GitHub Actions (e.g.
  to gate deploys on custom checks). It's disabled by default (guarded by
  a repo variable) so it won't conflict with the native integration unless
  deliberately enabled. See comments in that file for setup steps.

## Local development

```bash
npm install
npm run dev      # http://localhost:3000
npm run lint
npm run build && npm start   # production build, locally
```

## Hosting
- **Vercel** — zero-config for Next.js App Router projects. Custom domain
  can be attached in Project Settings → Domains once purchased/available.

## Future considerations
- Add `next/image` for the profile photo once a real image asset exists,
  for automatic optimization/responsive sizing.
- Add Vercel Analytics or Google Analytics (would live in
  `app/layout.js`).
- Consider TypeScript if the project grows or gains contributors.
- Consider migrating `lib/data.js` to a small headless CMS (e.g.
  Contentful, Sanity) if content needs to be edited without a deploy.
