# Memory Bank Index

This folder is the project's persistent context for any AI agent (or human)
picking up work on this repo. Read these files, in this order, before making
changes.

| File | Purpose |
|---|---|
| [`PRD.md`](./PRD.md) | What this product is, who it's for, scope, and success criteria. Read first. |
| [`resume.md`](./resume.md) | The canonical source content (Kreet Bhatnagar's resume). All site copy should trace back to this. |
| [`design.md`](./design.md) | Visual design system — colors, type, layout, motion, and the reasoning behind them. |
| [`tech-stack.md`](./tech-stack.md) | Framework, libraries, hosting, CI/CD, and key architectural decisions. |
| [`../agent.md`](../agent.md) | Root-level operating instructions for AI coding agents working in this repo. |
| [`../README.md`](../README.md) | Human-facing setup, local dev, and deployment instructions. |

## How content flows

```
resume.md (source of truth, human-readable)
      │
      ▼
lib/data.js (structured JS — the ONLY place UI components read content from)
      │
      ▼
components/*.js (render lib/data.js — no hardcoded copy in JSX)
```

If you update someone's experience, skills, or contact info: edit
`resume.md` for the record, then mirror the change into `lib/data.js`.
Never hardcode content directly inside a component.

## Current state (last updated at project creation)

- Framework: Next.js 14 (App Router), plain React + CSS (no Tailwind/UI kit).
- Single-page site, sections: Hero, About, Experience, Skills,
  Certifications, Projects, Accomplishments, Contact, Footer.
- Deployment target: Vercel, connected to a GitHub repo.
- CI: GitHub Actions runs lint + build on every push/PR.
- Photo: expected at `public/photo.jpeg`, falls back gracefully to an icon
  if absent.

## Conventions for future work

- Keep all page copy in `lib/data.js`.
- Keep global styling in `app/globals.css` using the existing CSS custom
  properties (`--primary`, `--accent`, etc.) — don't introduce a second
  styling system (e.g. Tailwind) without updating `tech-stack.md` and
  `design.md` first.
- New sections should follow the existing pattern: a data array/object in
  `lib/data.js`, a presentational component in `components/`, wrapped in
  `<Reveal>` for scroll-in animation where appropriate.
- Run `npm run lint` and `npm run build` locally before pushing — CI will
  block merges that fail either.
