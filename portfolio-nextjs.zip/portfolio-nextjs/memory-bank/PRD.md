# Product Requirements Document (PRD)

## Product
Personal portfolio website for **Kreet Bhatnagar**, ESG & Sustainability Professional.

## Goal
A single-page, fast-loading, visually polished portfolio site that:
1. Presents Kreet's ESG/sustainability experience, skills, certifications, and
   accomplishments to recruiters, hiring managers, and professional contacts.
2. Is easy to keep up to date (content lives in one data file, not scattered
   across markup).
3. Deploys automatically to production on every push to `main`, with a CI
   quality gate (lint + build) on every push and pull request.

## Primary audience
- Recruiters and hiring managers in ESG, sustainability, and corporate
  reporting roles.
- Professional network contacts (LinkedIn, email outreach).

## Success criteria
- Loads and is fully readable on mobile, tablet, and desktop.
- Passes CI (lint + build) on every commit.
- Deployed on Vercel with a live production URL, updating automatically on
  merge to `main`.
- Content (name, experience, skills, certifications, projects,
  accomplishments, contact info) is accurate and matches `resume.md`.
- Supports light/dark theme, persisted across visits.

## Scope (v1)
In scope:
- Hero / intro with photo, headline stats (years experience, certifications,
  ESG frameworks).
- About section with highlights.
- Experience timeline (work history) + education.
- Skills grid (ESG frameworks, core skills, tools).
- Certifications grid.
- Key projects grid.
- Accomplishments list.
- Contact section (phone, email, LinkedIn).
- Light/dark theme toggle.
- Responsive layout, scroll-reveal animations, subtle hover/tilt effects.
- CI (GitHub Actions: lint + build) and CD (Vercel, auto-deploy on push to
  `main`, preview deployments on PRs).

Out of scope (v1):
- CMS / admin panel for editing content without a code change.
- Blog / articles section.
- Multi-language support.
- Contact form with backend/email sending (contact is via `mailto:`/`tel:`
  links and LinkedIn for now).
- Analytics integration (can be added later — see `tech-stack.md` for where
  it would slot in).

## Content source of truth
- `memory-bank/resume.md` — canonical resume content.
- `lib/data.js` in the Next.js app — structured version of the same content,
  consumed by the UI. When the resume changes, update both.

## Non-functional requirements
- Accessible: semantic landmarks, alt text, visible focus states, honors
  `prefers-reduced-motion`.
- Performance: static-friendly Next.js App Router page, no heavy client
  bundles beyond small interactive widgets (theme toggle, reveal-on-scroll,
  counters, mobile nav, tilt effect).
- SEO: descriptive `<title>`/meta description, Open Graph tags, `robots.txt`.

## Open questions / future ideas
- Add a downloadable PDF resume link?
- Add testimonials/recommendations section?
- Add Google Analytics / Vercel Analytics?
- Custom domain (currently deploys to a `*.vercel.app` URL until one is
  attached in Vercel project settings).
