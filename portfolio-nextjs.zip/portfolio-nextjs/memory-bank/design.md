# Design System

This document records the visual design decisions carried over from the
original static `index.html` design and ported into the Next.js app's
`app/globals.css`. Treat it as the reference for any future visual changes.

## Concept
A clean, trustworthy "green sustainability" identity: deep forest-green
primary with a bright emerald accent, soft neutral surfaces, and a serif
display face for headings to read as professional/editorial rather than
purely corporate-SaaS.

## Color tokens (light theme)

| Token | Hex | Usage |
|---|---|---|
| `--primary` | `#0d5c3e` | Headings accents, buttons, links, icon backgrounds |
| `--primary-light` | `#1a7a5a` | Secondary gradient stop |
| `--primary-dark` | `#094a32` | Hover states, contact section gradient |
| `--accent` | `#2ecc71` | Glows, gradients, highlight details |
| `--accent-light` | `#a8e6cf` | Soft backgrounds, underline highlight |
| `--text` | `#1a1a2e` | Primary text |
| `--text-light` | `#4a4a5a` | Body copy |
| `--text-muted` | `#6b7280` | Captions, subtitles |
| `--bg` | `#fafbfc` | Page background |
| `--bg-alt` | `#f0f4f3` | Alternating section background |
| `--card-bg` | `#ffffff` | Card surfaces |
| `--border` | `#e5e7eb` | Hairlines |

Dark theme swaps these to a near-black background (`#0a0a0f`) with the
green/accent roles inverted (accent becomes the darker green, primary
becomes the bright emerald) so the palette still reads as "the same brand"
in both modes. See `[data-theme="dark"]` in `app/globals.css` for exact
values.

## Type

- **Display / headings**: `Playfair Display` (600/700 weight) — serif,
  used for `h1`/`h2` (`.hero h1`, `.section-title`).
- **Body / UI**: `Inter` (300–700 weight) — sans-serif, used for everything
  else.
- Loaded via Google Fonts `<link>` in `app/layout.js`.

## Layout

- Max content width: `1200px`, centered, `2rem` horizontal padding on
  mobile.
- Hero: two-column grid (text / photo) on desktop, stacks to a single
  column (photo above text) below `1024px`.
- Experience: vertical timeline, alternating left/right cards on desktop,
  collapses to a single left-aligned column with a left rail on mobile
  (`<768px`).
- Skills / Certifications / Projects: CSS grid (3 / 2 / 2 columns
  respectively on desktop), collapsing to 1 column on mobile.
- Section rhythm: `6rem 2rem` padding per `<section>`, alternating
  `--bg` / `--bg-alt` background bands to separate sections without
  hard borders.

## Motion

- Scroll-reveal: sections fade + slide up 30px as they enter the viewport
  (`.reveal` / `.reveal.active`, driven by `IntersectionObserver` in the
  `Reveal` component).
- Subtle ambient glow/pulse animations on the theme toggle, nav underline,
  timeline dots/rail, badges, and section title underline — intentionally
  slow (2–3s) and low-opacity so they read as "alive" without being
  distracting.
- Hover tilt (`TiltCard` component): highlight, project, and skill cards
  tilt slightly toward the cursor on `mousemove` and reset on
  `mouseleave`.
- Animated counters on the hero stats, triggered once when scrolled into
  view.
- `prefers-reduced-motion: reduce` is honored globally — all animations and
  transitions collapse to near-instant.

## Iconography
Font Awesome 6 (via CDN in `app/layout.js`) — solid icons for structural
UI (calendar, briefcase, cogs, etc.), the LinkedIn brand icon for the
LinkedIn link.

## Principles to preserve in future changes
1. Keep one accent color family (green) — don't introduce a second brand
   color without updating this doc.
2. Keep the serif/sans pairing; don't add a third typeface.
3. New sections should reuse existing card/section patterns
   (`.section-header`, `.section-title`, card components) rather than
   inventing new visual language per-section.
4. Any new animation should be as restrained as the existing ones — no more
   than one attention-drawing effect visible at a time.
