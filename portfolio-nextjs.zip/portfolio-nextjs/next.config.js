/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  eslint: {
    // Lint is run explicitly in CI (npm run lint); don't fail `next build` on warnings.
    ignoreDuringBuilds: false,
  },
};

module.exports = nextConfig;
