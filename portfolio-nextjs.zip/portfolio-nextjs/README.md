# Kreet Bhatnagar — Portfolio

Personal portfolio website for **Kreet Bhatnagar**, ESG & Sustainability
Professional. Built with Next.js 14 (App Router), deployed on Vercel with
GitHub Actions CI.

Live design ported 1:1 from an original static `index.html`/CSS design into
a maintainable Next.js app — see `memory-bank/design.md` for the full design
system and `memory-bank/tech-stack.md` for the architecture.

## Quick start

```bash
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

## Add your photo

Drop your photo at:

```
public/photo.jpeg
```

The hero section reads it from `/photo.jpeg` (see `lib/data.js` →
`profile.photo`). If it's missing, the site falls back to a placeholder
icon automatically — nothing breaks.

## Editing content

All copy (name, experience, skills, certifications, projects,
accomplishments, contact info) lives in **`lib/data.js`**. Edit that file —
no need to touch any component. Keep `memory-bank/resume.md` in sync as the
canonical record.

## Project structure

See `memory-bank/tech-stack.md` for the full breakdown. Short version:

```
app/            Next.js App Router: layout, page, global CSS
components/     One component per section + small interactive widgets
lib/data.js     All site content
memory-bank/    Project documentation (PRD, design system, tech stack, resume)
agent.md        Instructions for AI coding agents working in this repo
```

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | Start local dev server |
| `npm run build` | Production build (same as CI/Vercel run) |
| `npm start` | Serve the production build locally |
| `npm run lint` | Run ESLint |

## Deploying to Vercel (recommended path)

1. Push this repository to GitHub (see below).
2. Go to [vercel.com/new](https://vercel.com/new), click **Import Project**,
   and select this repo.
3. Vercel auto-detects Next.js — leave the default build settings (or they
   match `vercel.json` in this repo) and click **Deploy**.
4. From then on:
   - Every push to `main` → new **Production** deployment.
   - Every pull request → its own **Preview** deployment with a shareable
     URL, shown as a check on the PR.
5. (Optional) Attach a custom domain in **Project Settings → Domains**.

No GitHub Actions secrets are required for this path — Vercel's GitHub App
handles it directly.

## CI/CD pipeline

- **`.github/workflows/ci.yml`** — runs on every push and pull request:
  installs dependencies, `npm run lint`, `npm run build`. This is the
  quality gate; a failing lint or build blocks the PR from looking "green."
- **`.github/workflows/deploy-vercel.yml`** — optional, disabled by
  default. Only needed if you want deploys to run explicitly through GitHub
  Actions instead of Vercel's native Git integration. See the comments at
  the top of that file for the required secrets and how to enable it.

## Pushing this project to your portfolio repo

If you're starting from this zip and haven't initialized git yet:

```bash
git init
git add .
git commit -m "Initial Next.js portfolio"
git branch -M main
git remote add origin <your-repo-url>
git push -u origin main
```

If your portfolio repo already exists with history, instead copy these
files into your existing repo (keeping your repo's `.git` folder), resolve
any conflicts, then commit and push as usual.

## License

Personal project — all rights reserved by Kreet Bhatnagar.
